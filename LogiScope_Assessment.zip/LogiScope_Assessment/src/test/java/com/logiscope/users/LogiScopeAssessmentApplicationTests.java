package com.logiscope.users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogiScopeAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
