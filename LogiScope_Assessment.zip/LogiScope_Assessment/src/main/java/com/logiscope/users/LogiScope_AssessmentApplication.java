package com.logiscope.users;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogiScope_AssessmentApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(LogiScope_AssessmentApplication.class, args);
		System.out.println("SprinBoot");
	}


}
